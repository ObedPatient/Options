package rw.evolve.eprocurement.execution_period_options;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExecutionPeriodOptionsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExecutionPeriodOptionsApplication.class, args);
	}

}
