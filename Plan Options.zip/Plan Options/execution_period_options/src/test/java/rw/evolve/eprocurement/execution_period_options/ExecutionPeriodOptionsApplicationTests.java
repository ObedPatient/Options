package rw.evolve.eprocurement.execution_period_options;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExecutionPeriodOptionsApplicationTests {

	@Test
	void contextLoads() {
	}

}
