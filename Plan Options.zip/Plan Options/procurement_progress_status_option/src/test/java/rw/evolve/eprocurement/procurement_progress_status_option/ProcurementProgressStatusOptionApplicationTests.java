package rw.evolve.eprocurement.procurement_progress_status_option;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcurementProgressStatusOptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
