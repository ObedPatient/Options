package rw.evolve.eprocurement.procurement_progress_status_option;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProcurementProgressStatusOptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProcurementProgressStatusOptionApplication.class, args);
	}

}
