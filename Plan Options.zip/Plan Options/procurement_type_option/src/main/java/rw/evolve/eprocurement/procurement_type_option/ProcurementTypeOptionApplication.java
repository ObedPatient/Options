package rw.evolve.eprocurement.procurement_type_option;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProcurementTypeOptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProcurementTypeOptionApplication.class, args);
	}

}
