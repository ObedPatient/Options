package rw.evolve.eprocurement.procurement_type_option;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcurementTypeOptionModelApplicationTests {

	@Test
	void contextLoads() {
	}

}
