package rw.evolve.eprocurement.source_of_fund_option;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SourceOfFundOptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
