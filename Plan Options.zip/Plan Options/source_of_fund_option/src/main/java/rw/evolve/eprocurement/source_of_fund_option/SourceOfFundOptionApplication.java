package rw.evolve.eprocurement.source_of_fund_option;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SourceOfFundOptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SourceOfFundOptionApplication.class, args);
	}

}
