package rw.evolve.eprocurement.procurement_method_option;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProcurementMethodOptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProcurementMethodOptionApplication.class, args);
	}

}
