package rw.evolve.eprocurement.procurement_method_option;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcurementMethodOptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
