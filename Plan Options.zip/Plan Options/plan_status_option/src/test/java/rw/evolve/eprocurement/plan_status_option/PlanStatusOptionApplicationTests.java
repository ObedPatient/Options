package rw.evolve.eprocurement.plan_status_option;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlanStatusOptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
