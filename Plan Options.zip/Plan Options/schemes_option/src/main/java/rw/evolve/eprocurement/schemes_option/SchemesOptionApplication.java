package rw.evolve.eprocurement.schemes_option;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchemesOptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchemesOptionApplication.class, args);
	}

}
