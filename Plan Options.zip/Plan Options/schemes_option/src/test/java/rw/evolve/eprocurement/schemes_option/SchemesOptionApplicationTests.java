package rw.evolve.eprocurement.schemes_option;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchemesOptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
