package rw.evolve.eprocurement.unit_of_measure_options;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnitOfMeasureOptionsApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnitOfMeasureOptionsApplication.class, args);
	}

}
