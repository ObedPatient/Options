package rw.evolve.eprocurement.unit_of_measure_options;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnitOfMeasureOptionsApplicationTests {

	@Test
	void contextLoads() {
	}

}
