package rw.evolve.eprocurement.prerequisites_activity_type_options;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrerequisitesActivityTypeOptionsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrerequisitesActivityTypeOptionsApplication.class, args);
	}

}
