package rw.evolve.eprocurement.prerequisites_activity_type_options;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrerequisitesActivityTypeOptionsApplicationTests {

	@Test
	void contextLoads() {
	}

}
